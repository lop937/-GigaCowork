#!/usr/bin/env python3
"""Генератор синтетических данных для агента распределения ФУЛ.

Создаёт три файла Excel (ФУЛ из 1С, реестр Cloud, сотрудники из 1С) и эталон.
Все компании, бренды и сотрудники вымышленные. Результат детерминирован.

Запуск:
    python3 generate_data.py --out data                     # основной набор
    python3 generate_data.py --out data_B --variant shuffled  # те же данные, но
        другой порядок колонок, лишние колонки и другие названия листов
Нужен только openpyxl.
"""
import argparse
import os
import random
from datetime import datetime, timedelta

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

G_AIR, G_VED, G_MM = "авиаперевозки", "ВЭД", "мультимодальные перевозки"
G_UND, NA = "не определено", "—"
POS_AIR = "Специалист по авиаперевозкам"
POS_VED = "Специалист по работе с ВЭД документацией"
POS_MM = "Специалист по мультимодальным перевозкам"

S_NEW, S_REPEAT, S_DUP, S_FULLDUP = "новый", "повторная отправка", "дубль в пачке", "полный дубль"
S_SKIP, S_NONUM = "возможный пропуск", "нет номера заказа"

EMPLOYEES = [
    ("Петров Алексей Игоревич", "Работает", POS_AIR, "00101"),
    ("Смирнова Ольга Викторовна", "Работает", POS_AIR, "00102"),
    ("Кузнецов Денис Сергеевич", "Уволен", POS_AIR, "00103"),
    ("Морозова Анна Павловна", "Отпуск по уходу за ребёнком", POS_VED, "00201"),
    ("Волков Игорь Николаевич", "Уволен", POS_VED, "00202"),
    ("Соколова Мария Андреевна", "Работает", POS_MM, "00301"),
    ("Лебедев Павел Олегович", "Работает", POS_MM, "00302"),
    ("Новиков Артём Дмитриевич", "Отпуск ежегодный", POS_MM, "00303"),
    ("Зайцева Елена Романовна", "Работает", "Ассистент", "00401"),
    ("Фёдоров Сергей Михайлович", "Работает", "Руководитель группы", "00501"),
]

CLOUD_HEADERS = ["Заказ", "Поставщик", "Бренд", "Логист", "статус", "дата подтверждения",
                 "cut-off", "Дата получения УЛ", "Страна отправления", "Способ доставки",
                 "Документы получены (дата)", "Комментарий"]
FUL_HEADERS = ["Дата", "Cut-off date", "Номер", "Статус", "Комментарий", "Способ доставки",
               "Бизнес единица", "Логист", "Контрагент", "Страна"]
EMP_HEADERS = ["Наименование", "Текущее состояние", "Должность", "Код"]

# история Cloud: заказ, поставщик, бренд, логист, статус, дата УЛ, страна, способ, комментарий
HISTORY = [
    ("S0000101", "Aero Textile Co", "Nordline", "Петров А.И.", "в работе", "2026-10-14", "Китай", "air", ""),
    ("S0000102", "Aero Textile Co", "Nordline", "Петров А.И.", "в работе", "2026-09-28", "Китай", "air",
     "Повторная отправка ФУЛа, 02.10.2026"),
    ("S0000103", "Aero Textile Co", "Nordline", "Петров А.", "confirm", "2026-09-10", "Китай", "air", ""),
    ("S0000104", "Aero Textile Co", "Nordline", "Петров А.И.", "confirm", "2026-08-28", "Китай", "air", ""),
    ("S0000105", "SkyWear Ltd", "Urbanica", "Кузнецов Д.С.", "confirm", "2026-09-05", "Турция", "air", ""),
    ("S0000106", "SkyWear Ltd", "Urbanica", "Кузнецов Д.С.", "confirm", "2026-09-18", "Турция", "air", ""),
    ("S0000107", "SkyWear Ltd", "Urbanica", "кузнецов д.", "confirm", "2026-09-30", "Турция", "air", ""),
    ("S0000108", "SkyWear Ltd", "Urbanica", "Смирнова О.В.", "в работе", "2026-10-10", "Турция", "air", ""),
    ("S0000109", "Pacific Wear", "Nordline", "Смирнова О.В.", "confirm", "2026-09-22", "Япония", "air", ""),
    ("S0000110", "Лотос Трейд", "Urbanica", "Соколова М.А.", "в работе", "2026-10-08", "Вьетнам", "sea", ""),
    ("S0000111", "Лотос Трейд", "Urbanica", "Соколова М.А.", "confirm", "2026-09-12", "Вьетнам", "sea", ""),
    ("S0000112", "Лотос Трейд", "Urbanica", "Соколова М.", "confirm", "2026-08-30", "Вьетнам", "sea", ""),
    ("S0000113", "Лотос Трейд", "Urbanica", "Белов И.", "confirm", "2026-09-25", "Вьетнам", "sea", ""),
    ("S0000114", "ТД Север", "Nordline", "Новиков А.Д.", "confirm", "2026-09-02", "Казахстан", "railway", ""),
    ("S0000115", "ТД Север", "Nordline", "Новиков А.Д.", "confirm", "2026-09-20", "Казахстан", "railway", ""),
    ("S0000116", "ТД Север", "Nordline", "Новиков А.Д.", "в работе", "2026-10-06", "Казахстан", "railway", ""),
    ("S0000117", "ТД Север", "Nordline", "Лебедев П.О.", "confirm", "2026-09-29", "Казахстан", "truck", ""),
    ("S0000118", "Baltic Garments", "Urbanica", "Лебедев П.О.", "в работе", "2026-10-15", "Польша", "truck", ""),
    ("S0000119", "Baltic Garments", "Urbanica", "Лебедев П.О.", "в работе", "2026-10-17", "Польша", "direct truck", ""),
    ("S0000120", "Baltic Garments", "Urbanica", "Лебедев П.О.", "confirm", "2026-09-08", "Польша", "truck", ""),
    ("S0000121", "Мода Юг", "Nordline", "Соколова М.А.", "в работе", "2026-10-20", "Румыния", "truck", ""),
    ("S0000122", "Alpine Cotton", "Urbanica", "Соколова М.А.", "confirm", "2026-09-14", "Австрия", "truck", ""),
    ("S0000123", "Alpine Cotton", "Urbanica", "Соколова М.А.", "confirm", "2026-08-26", "Италия", "truck", ""),
    ("S0000124", "ООО Ромашка", "Nordline", "Морозова А.П.", "confirm", "2026-09-04", "Китай", "sea", ""),
    ("S0000125", "ООО Ромашка", "Nordline", "Морозова А.П.", "confirm", "2026-09-19", "Китай", "railway", ""),
    ("S0000126", "ООО Ромашка", "Nordline", "Морозова А.П.", "confirm", "2026-09-27", "Китай", "sea", ""),
    ("S0000127", "ООО Ромашка", "Nordline", "Волков И.Н.", "confirm", "2026-08-29", "Китай", "sea", ""),
    ("S0000128", "Shenzhen Silk Co", "Urbanica", "Волков И.Н.", "confirm", "2026-09-09", "Китай", "railway", ""),
    ("S0000129", "Shenzhen Silk Co", "Urbanica", "Волков И.Н.", "confirm", "2026-09-24", "Китай", "sea", ""),
    ("S0000130", "HK Fashion Trading", "Nordline", "Морозова А.П.", "confirm", "2026-09-16", "Гонконг", "sea", ""),
    ("S0000131", "Silk Road Trading", "Urbanica", "Морозова А.П.", "confirm", "2026-09-21", "Китай", "sea", ""),
    ("S0000132", "Silk Road Trading", "Urbanica", "Волков И.Н.", "confirm", "2026-09-06", "Китай", "sea", ""),
]
LAST_CLOUD_DATE = "20.10.2026"

REP = "Повторная отправка ФУЛа, "


def d(s):
    return datetime.strptime(s, "%Y-%m-%d")


def clean(s):
    return " ".join(str(s).split())


def short_name(full):
    sur, first, pat = full.split()
    return f"{sur} {first[0]}.{pat[0]}."


def fdt(day, hh, mm):
    return datetime(2026, 10, day, hh, mm)


# логические ФУЛ: key, dt, order(None = нет), метод, бренд, поставщик, страна, логист_в_фул, ожидание
# ожидание: статус, группа, логист, комментарий строки Cloud, создаётся строка, внимание, основание
def case(key, dt, order, method, brand, supplier, country, logist_in, status, group, logist,
         comment, row, attention, reason, comment_in=None, cut_days=30):
    return dict(key=key, dt=dt, order=order, method=method, brand=brand, supplier=supplier,
                country=country, logist_in=logist_in, status=status, group=group, logist=logist,
                comment=comment, row=row, attention=attention, reason=reason,
                comment_in=comment_in, cut_days=cut_days)


CASES = [
    case("F01", fdt(12, 9, 15), "S0000201", "sea", "Urbanica", "Shenzhen Silk Co", "Китай", "",
         S_SKIP, NA, NA, "", False, False,
         f"Заказа нет в Cloud, дата ФУЛ 12.10.2026 раньше последней записи Cloud ({LAST_CLOUD_DATE}); строка не создаётся, решает человек"),
    case("F02", fdt(15, 14, 40), "S0000202", "air", "Nordline", "Aero Textile Co", "Китай", "",
         S_SKIP, NA, NA, "", False, False,
         f"Заказа нет в Cloud, дата ФУЛ 15.10.2026 раньше последней записи Cloud ({LAST_CLOUD_DATE}); строка не создаётся, решает человек"),
    case("F03", fdt(21, 8, 5), "S0000301", "air", "Nordline", "Aero Textile Co", "Китай", "",
         S_NEW, G_AIR, "Петров А.И.", "", True, False,
         "air → авиаперевозки; поставщик ведёт Петров (4 заказа в истории, остальных нет), он работает"),
    case("F04", fdt(21, 8, 20), "S0000302", "air", "Urbanica", "SKYWEAR LTD.", "Турция", "Кузнецов Д.С.",
         S_NEW, G_AIR, "Смирнова О.В.", "", True, False,
         "Предпочтительный Кузнецов (3 заказа) уволен → наименее загруженный в группе: Смирнова (1) против Петрова (3). Логист из колонки ФУЛ игнорируется"),
    case("F05", fdt(21, 8, 35), "S0000303", "air", "Urbanica", " skywear   ltd ", "Турция", "",
         S_NEW, G_AIR, "Смирнова О.В.", "", True, False,
         "Тот же поставщик в пачке (другое написание) → тот же логист, что и в ФУЛ000404"),
    case("F06", fdt(21, 8, 50), "S0000304", "air", "Nordline", "Fly Fashion", "Индия", "",
         S_NEW, G_AIR, "Петров А.И.", "", True, False,
         "Новый поставщик → наименее загруженный: Петров и Смирнова по 3 заказа, ничья → меньший табельный номер (00101)"),
    case("F07", fdt(21, 9, 10), "S0000305", "sea", "Urbanica", "Лотос Трейд", "Вьетнам", "",
         S_NEW, G_MM, "Соколова М.А.", "", True, False,
         "не air, страна не Китай → мультимодальные; поставщика ведёт Соколова (3 заказа); «Белов И.» из истории не найден среди сотрудников и не учитывается"),
    case("F08", fdt(21, 9, 25), "S0000306", "railway", "Nordline", "ТД Север", "Казахстан", "",
         S_NEW, G_MM, "Лебедев П.О.", "", True, False,
         "Предпочтительный Новиков (3 заказа) в отпуске → наименее загруженный: Лебедев (2) против Соколовой (3)"),
    case("F09", fdt(21, 9, 40), "S0000307", "truck", "Nordline", "ТД Север", "Казахстан", "",
         S_NEW, G_MM, "Лебедев П.О.", "", True, False,
         "Тот же поставщик в пачке → тот же логист (Лебедев), один поставщик — один логист"),
    case("F10", fdt(21, 10, 5), "S0000308", "truck", "Urbanica", "Baltic Garments", "Польша", "",
         S_NEW, G_MM, "Лебедев П.О.", "", True, False,
         "Поставщика ведёт Лебедев (3 заказа), он работает"),
    case("F11", fdt(21, 10, 20), "S0000309", "sea", "Nordline", "Norte Moda", "Бразилия", "",
         S_NEW, G_MM, "Соколова М.А.", "", True, False,
         "Новый поставщик → наименее загруженный: Соколова (3) против Лебедева (5)"),
    case("F12", fdt(22, 10, 0), "S0000102", "air", "Nordline", "Aero Textile Co", "Китай", "Петров А.И.",
         S_REPEAT, NA, NA, "Повторная отправка ФУЛа, 02.10.2026; Повторная отправка ФУЛа, 22.10.2026",
         False, False,
         "Заказ уже в Cloud (в работе) → новой строки нет, к существующему комментарию дописывается повторная отправка"),
    case("F13", fdt(22, 11, 0), "S0000115", "railway", "Nordline", "ТД Север", "Казахстан", "",
         S_REPEAT, NA, NA, "Повторная отправка ФУЛа, 22.10.2026", False, False,
         "Заказ уже в Cloud (статус confirm) → новой строки нет, комментарий «Повторная отправка ФУЛа, 22.10.2026»"),
    case("F14", fdt(22, 12, 0), "S0000310", "truck", "Nordline", "Мода Юг", "Румыния", "",
         S_NEW, G_MM, "Соколова М.А.", "Повторная отправка ФУЛа, 22.10.2026", True, False,
         "Новый заказ, поставщика ведёт Соколова; второй ФУЛ того же заказа в пачке (ФУЛ000415) даёт комментарий о повторной отправке"),
    case("F15", fdt(22, 12, 30), "S0000310", "truck", "Nordline", "Мода Юг", "Румыния", "",
         S_DUP, NA, NA, "", False, False,
         "Заказ S0000310 уже создан в этой пачке другим ФУЛ → новой строки нет, дата дописана в комментарий первой строки"),
    case("F16", fdt(22, 13, 0), "S0000311", "sea", "Nordline", 'ООО "Ромашка"', "Китай", "",
         S_NEW, G_VED, "", "", True, True,
         "не air + Китай → ВЭД; все сотрудники ВЭД недоступны (отпуск, уволен) → логист пуст, в другую группу не передаём"),
    case("F17", fdt(22, 13, 15), "S0000312", "railway", "Urbanica", "Shenzhen Silk Co", "Гонконг", "",
         S_NEW, G_VED, "", "", True, True,
         "Гонконг приравнен к Китаю → ВЭД; вся группа недоступна → логист пуст"),
    case("F18", fdt(22, 13, 30), "S0000313", "sea", "Nordline", "Dragon Garment", "КНР", "",
         S_NEW, G_VED, "", "", True, True,
         "КНР = Китай → ВЭД; вся группа недоступна → логист пуст"),
    case("F19", fdt(22, 14, 0), None, "air", "Nordline", "Aero Textile Co", "Китай", "",
         S_NONUM, NA, NA, "", False, True,
         "В комментарии нет номера заказа → строка не создаётся, ФУЛ в «Требует внимания»", comment_in="Номер заказа уточняется"),
    case("F20", fdt(22, 14, 15), "S0000314", "sea", "Urbanica", "Лотос Трейд", "", "",
         S_NEW, G_UND, "", "", True, True,
         "Не air и нет страны → группа не определена, логист не назначается, страну не подставляем"),
    case("F21", fdt(22, 14, 30), "S0000315", "", "Urbanica", "Лотос Трейд", "Вьетнам", "",
         S_NEW, G_UND, "", "", True, True,
         "Нет способа доставки → группа не определена, логист не назначается, способ не подставляем"),
    case("F22", fdt(22, 14, 45), "S0000316", "air", "Nordline", " fly fashion", "", "",
         S_NEW, G_AIR, "Петров А.И.", "", True, False,
         "air → авиаперевозки, страна для air не нужна и остаётся пустой; поставщик уже в пачке у Петрова"),
    case("F23", fdt(22, 15, 0), "S0000317", "truck", "Urbanica", "", "Польша", "",
         S_NEW, G_MM, "", "", True, True,
         "Нет поставщика → группа определена, но логист не назначается (нет истории и нельзя применить «один поставщик — один логист»)"),
    case("F24", fdt(21, 8, 5), "S0000301", "air", "Nordline", "Aero Textile Co", "Китай", "",
         S_FULLDUP, NA, NA, "", False, False,
         "Повторная строка с тем же номером ФУЛ (ФУЛ000403) → полный дубль, игнорируется"),
]

NUMBERS = {c["key"]: f"ФУЛ{400 + i + 1:06d}" for i, c in enumerate(CASES)}
NUMBERS["F24"] = NUMBERS["F03"]

TRAPS = [
    ("Повторная отправка заказа, который уже есть в Cloud", ["F12", "F13"],
     "Не создавать строку, дописать «Повторная отправка ФУЛа, [дата ФУЛ]» к комментарию существующей строки"),
    ("Повтор того же заказа внутри пачки (другой номер ФУЛ)", ["F14", "F15"],
     "Создать одну строку; второй ФУЛ даёт комментарий о повторной отправке в этой строке"),
    ("Полный дубль строки выгрузки", ["F03", "F24"],
     "Вторую строку игнорировать, строку Cloud не создавать"),
    ("Новый поставщик", ["F06", "F11"], "Выбрать наименее загруженного, ничья — меньший табельный номер"),
    ("Предпочтительный логист уволен", ["F04"], "Выбрать наименее загруженного доступного в группе"),
    ("Предпочтительный логист в отпуске", ["F08"], "Выбрать наименее загруженного доступного в группе"),
    ("Вся группа ВЭД недоступна (отпуск, уволен)", ["F16", "F17", "F18"],
     "Строку создать, логист пустой, в другую группу не передавать, ФУЛ в «Требует внимания»"),
    ("Нет номера заказа", ["F19"], "Строку не создавать, ФУЛ в «Требует внимания»"),
    ("Нет страны (не air)", ["F20"], "Группа «не определено», логист пуст, страну не подставлять"),
    ("Нет способа доставки", ["F21"], "Группа «не определено», логист пуст, способ не подставлять"),
    ("Нет страны, но air", ["F22"], "Группа авиаперевозки определяется без страны"),
    ("Нет поставщика", ["F23"], "Логист пуст, ФУЛ в «Требует внимания»"),
    ("ФУЛ раньше последней записи Cloud", ["F01", "F02"],
     "Не создавать строку, показать в «Возможные пропуски»"),
    ("Поставщик в разном написании (регистр, пробелы, знаки)", ["F04", "F05", "F16", "F22"],
     "Считать одним поставщиком и применять «один поставщик — один логист»"),
    ("Короткие имена в Cloud и неизвестный логист", ["F07"],
     "«Петров А.», «кузнецов д.» сопоставить с ФИО; «Белов И.» не найден → не учитывать"),
    ("Ассистент и руководитель без нагрузки", ["F06", "F11"],
     "Не назначать, хотя состояние «Работает» и нагрузка нулевая"),
    ("Китай, Гонконг, КНР", ["F16", "F17", "F18"], "Все три → группа ВЭД"),
    ("Логист в колонке ФУЛ не совпадает с выбором агента", ["F04", "F12"],
     "Колонку «Логист» в ФУЛ игнорировать"),
]

ASSUMPTIONS = [
    "Ключ повтора — номер заказа из комментария «Номер: S0001234 от ДД.ММ.ГГГГ».",
    "Заказ есть в Cloud в любом статусе → повторная отправка, строка не создаётся.",
    "Возможный пропуск: заказа нет в Cloud, а дата ФУЛ раньше максимальной «Даты получения УЛ» в Cloud.",
    "Группа: air → авиа; не air + Китай/КНР/Гонконг → ВЭД; не air + другая страна → мультимодальные; нет способа или страны (не air) → не определено.",
    "Кандидаты: состояние «Работает» и должность специалиста нужной группы; ассистенты и руководители не назначаются.",
    "Предпочтительный логист: больше всего заказов поставщика в истории Cloud внутри группы; недоступен → наименее загруженный.",
    "Загрузка: заказы «в работе» в Cloud плюс заказы, назначенные в этой пачке; ничья → меньший табельный номер.",
    "Один поставщик в пачке — один логист внутри группы; ФУЛ обрабатываются по возрастанию даты.",
    "Нет номера заказа → строка не создаётся; нет поставщика, способа или страны → строка создаётся, недостающее поле пустое, логист пуст.",
    "Новая строка Cloud: статус «в работе», дата получения УЛ = дата ФУЛ, cut-off из ФУЛ, остальное пусто.",
    "Логист в Cloud записывается как «Фамилия И.О.»; сопоставление по фамилии и инициалам, неоднозначное или неизвестное имя не учитывается.",
    "Колонка «Логист» в выгрузке ФУЛ игнорируется.",
]


def build_cloud_rows():
    rows = []
    for o, sup, br, lg, st, ul, co, me, cm in HISTORY:
        u = d(ul)
        conf = u + timedelta(days=5) if st == "confirm" else None
        docs = u + timedelta(days=9) if st == "confirm" else None
        rows.append([o, sup, br, lg, st, conf, u + timedelta(days=21), u, co, me, docs, cm])
    return rows


def ful_row(c):
    if c["order"]:
        cm = f"Номер: {c['order']} от {(c['dt'] - timedelta(days=15)):%d.%m.%Y}"
    else:
        cm = c["comment_in"]
    cut = datetime(c["dt"].year, c["dt"].month, c["dt"].day) + timedelta(days=c["cut_days"])
    return {"Дата": c["dt"], "Cut-off date": cut, "Номер": NUMBERS[c["key"]], "Статус": "Проведен",
            "Комментарий": cm, "Способ доставки": c["method"], "Бизнес единица": c["brand"],
            "Логист": c["logist_in"], "Контрагент": c["supplier"], "Страна": c["country"]}


def expected_cloud_row(c):
    dt = c["dt"]
    cut = datetime(dt.year, dt.month, dt.day) + timedelta(days=c["cut_days"])
    return [c["order"], clean(c["supplier"]), c["brand"], c["logist"], "в работе", None, cut,
            datetime(dt.year, dt.month, dt.day), clean(c["country"]), c["method"], None, c["comment"]]


def write_sheet(wb, title, headers, rows, extra=None, order=None):
    """rows — список словарей {заголовок: значение}; extra — доп. колонки; order — порядок."""
    ws = wb.create_sheet(title)
    cols = list(headers) + list((extra or {}).keys())
    if order:
        cols = order
    ws.append(cols)
    for cell in ws[1]:
        cell.font = Font(bold=True)
    for i, r in enumerate(rows):
        full = dict(r)
        for k, f in (extra or {}).items():
            full[k] = f(i)
        ws.append([full.get(c) for c in cols])
    for j, name in enumerate(cols, start=1):
        ws.column_dimensions[get_column_letter(j)].width = max(14, min(42, len(name) + 6))
        for cell in ws[get_column_letter(j)][1:]:
            if isinstance(cell.value, datetime):
                has_time = cell.value.hour or cell.value.minute
                cell.number_format = "DD.MM.YYYY HH:MM" if has_time else "DD.MM.YYYY"
    ws.freeze_panes = "A2"
    return ws


def save(wb, path):
    del wb["Sheet"]
    wb.properties.created = datetime(2026, 10, 1)
    wb.properties.modified = datetime(2026, 10, 1)
    wb.properties.creator = "generator"
    wb.save(path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="data")
    ap.add_argument("--variant", choices=["base", "shuffled"], default="base")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    shuffled = a.variant == "shuffled"
    rnd = random.Random(2026)

    # порядок строк ФУЛ в файле перемешан (одинаков в обоих вариантах)
    order = list(range(len(CASES)))
    random.Random(7).shuffle(order)
    cases_in_file = [CASES[i] for i in order]
    for pos, c in enumerate(cases_in_file, start=2):
        c["file_row"] = pos
    # F03 и F24 — одинаковые строки: «оригиналом» считается та, что стоит в файле раньше,
    # поэтому при необходимости меняем местами их строки в эталоне
    by = {c["key"]: c for c in CASES}
    if by["F24"]["file_row"] < by["F03"]["file_row"]:
        by["F24"]["file_row"], by["F03"]["file_row"] = by["F03"]["file_row"], by["F24"]["file_row"]

    ful_rows = [ful_row(c) for c in cases_in_file]
    cloud_rows = [dict(zip(CLOUD_HEADERS, r)) for r in build_cloud_rows()]
    emp_rows = [dict(zip(EMP_HEADERS, (f, s, p, t))) for f, s, p, t in EMPLOYEES]

    names = ("ФУЛ", "Cloud", "Сотрудники")
    ful_cols = FUL_HEADERS
    cloud_cols = CLOUD_HEADERS
    emp_cols = EMP_HEADERS
    extra_ful = extra_cloud = extra_emp = None
    if shuffled:
        names = ("Лист1", "Реестр заказов", "Сотрудники 1С")
        extra_ful = {"Вес, кг": lambda i: 120 + 7 * i, "Склад": lambda i: "Москва"}
        extra_cloud = {"Приоритет": lambda i: "обычный"}
        extra_emp = {"Подразделение": lambda i: "Логистика"}
        ful_cols = FUL_HEADERS + list(extra_ful)
        cloud_cols = CLOUD_HEADERS + list(extra_cloud)
        emp_cols = EMP_HEADERS + list(extra_emp)
        rnd.shuffle(ful_cols)
        rnd.shuffle(cloud_cols)
        rnd.shuffle(emp_cols)

    wb = Workbook()
    write_sheet(wb, names[0], FUL_HEADERS, ful_rows, extra_ful, ful_cols if shuffled else None)
    save(wb, os.path.join(a.out, "1_Выгрузка_ФУЛ_1С.xlsx"))
    wb = Workbook()
    write_sheet(wb, names[1], CLOUD_HEADERS, cloud_rows, extra_cloud, cloud_cols if shuffled else None)
    save(wb, os.path.join(a.out, "2_Реестр_Cloud.xlsx"))
    wb = Workbook()
    write_sheet(wb, names[2], EMP_HEADERS, emp_rows, extra_emp, emp_cols if shuffled else None)
    save(wb, os.path.join(a.out, "3_Сотрудники_1С.xlsx"))

    # эталон
    wb = Workbook()
    ws = wb.create_sheet("Эталон_по_ФУЛ")
    ws.append(["Строка ФУЛ", "Номер ФУЛ", "Заказ", "Статус", "Группа", "Логист", "Строка Cloud создана",
               "Комментарий в Cloud", "Требует внимания", "Основание", "Ключ случая"])
    for c in sorted(cases_in_file, key=lambda x: x["file_row"]):
        ws.append([c["file_row"], NUMBERS[c["key"]], c["order"] or "", c["status"], c["group"],
                   c["logist"] if c["logist"] != "" else "не определено" if c["status"] == S_NEW else "",
                   "да" if c["row"] else "нет", c["comment"], "да" if c["attention"] else "нет",
                   c["reason"], c["key"]])
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="305496")
    for j, w in enumerate([11, 14, 12, 20, 26, 16, 14, 52, 12, 100, 10], start=1):
        ws.column_dimensions[get_column_letter(j)].width = w
    ws.freeze_panes = "A2"

    new_cases = sorted((c for c in CASES if c["row"]), key=lambda x: (x["dt"], NUMBERS[x["key"]]))
    write_sheet(wb, "Эталон_строки_Cloud", CLOUD_HEADERS,
                [dict(zip(CLOUD_HEADERS, expected_cloud_row(c))) for c in new_cases])

    ws = wb.create_sheet("Ловушки")
    ws.append(["Ловушка", "Строки ФУЛ в файле", "Что обязан сделать агент"])
    for cell in ws[1]:
        cell.font = Font(bold=True)
    by_key = {c["key"]: c["file_row"] for c in CASES}
    for name, keys, action in TRAPS:
        ws.append([name, ", ".join(str(by_key[k]) for k in keys), action])
    for j, w in enumerate([58, 22, 90], start=1):
        ws.column_dimensions[get_column_letter(j)].width = w

    ws = wb.create_sheet("Допущения")
    ws.append(["№", "Допущение, на котором построен эталон"])
    for cell in ws[1]:
        cell.font = Font(bold=True)
    for i, t in enumerate(ASSUMPTIONS, start=1):
        ws.append([i, t])
    ws.column_dimensions["B"].width = 140

    ws = wb.create_sheet("Итоги")
    ws.append(["Показатель", "Значение"])
    cnt = lambda s: sum(1 for c in CASES if c["status"] == s)
    ws.append(["Всего строк в выгрузке ФУЛ", len(CASES)])
    ws.append(["Новых строк Cloud", sum(1 for c in CASES if c["row"])])
    ws.append(["Повторных отправок", cnt(S_REPEAT)])
    ws.append(["Дублей внутри пачки", cnt(S_DUP)])
    ws.append(["Полных дублей", cnt(S_FULLDUP)])
    ws.append(["Возможных пропусков", cnt(S_SKIP)])
    ws.append(["ФУЛ без номера заказа", cnt(S_NONUM)])
    ws.append(["В «Требует внимания»", sum(1 for c in CASES if c["attention"])])
    ws.column_dimensions["A"].width = 36
    save(wb, os.path.join(a.out, "Эталон.xlsx"))
    print(f"Готово: {a.out} ({a.variant}); ФУЛ: {len(CASES)}, Cloud: {len(HISTORY)}, сотрудников: {len(EMPLOYEES)}")


if __name__ == "__main__":
    main()
